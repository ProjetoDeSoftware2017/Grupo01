<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "1234";
	$dbname = "mydbnovo";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

	?>